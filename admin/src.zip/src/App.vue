<script setup>
// Component logic can be added here if needed
</script>

<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<style>
/* Global styles can be added here */
</style>
