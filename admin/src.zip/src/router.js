import { createRouter, createWebHistory } from 'vue-router'
import Home from './components/Home.vue'
import Product from './components/Product.vue'
import Bill from './components/Bill.vue'

const routes = [
    {
        path: '/',
        name: 'Home',
        component: Home
    },
    {
        path: '/product',
        name: 'Product',
        component: Product
    },
    {
        path: '/bill',
        name: 'Bill',
        component: Bill
    }
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

export default router 